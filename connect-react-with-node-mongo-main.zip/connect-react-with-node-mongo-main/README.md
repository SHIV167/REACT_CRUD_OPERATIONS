# Code for CoderDost Youtube video on Connecting REACT with NODE and MONGO


Two folder of front-end and back-end are provided separately.

Front-end : `react-app`
Back-end : `node-sever`

## Installation 
After downloading, in each folder you have to use `npm install` separately.

And in both you can start separately a server

`npm start` for front-end
`node index.js` for back-end (or you can use `nodemon`)
